using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Domain;

namespace EquipmentBorrowing.Infrastructure.Repositories;

/// <summary>
/// Simple in-memory implementation of <see cref="IBorrowingRepository"/>.
/// Assigns each new borrowing a sequential id, the way an auto-increment
/// primary key would in a real database.
/// </summary>
public class InMemoryBorrowingRepository : IBorrowingRepository
{
    private readonly List<Borrowing> _borrowings = new();
    private int _nextId = 1;

    public Task<int> CountActiveByStudentIdAsync(int studentId, CancellationToken cancellationToken = default)
    {
        var count = _borrowings.Count(b => b.StudentId == studentId && b.Status == BorrowingStatus.Active);
        return Task.FromResult(count);
    }

    public Task<Borrowing?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var borrowing = _borrowings.FirstOrDefault(b => b.Id == id);
        return Task.FromResult(borrowing);
    }

    public Task<IReadOnlyList<Borrowing>> GetActiveAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyList<Borrowing> active = _borrowings
            .Where(b => b.Status == BorrowingStatus.Active)
            .ToList();

        return Task.FromResult(active);
    }

    public Task<Borrowing> AddAsync(Borrowing borrowing, CancellationToken cancellationToken = default)
    {
        var persisted = new Borrowing(
            _nextId++,
            borrowing.StudentId,
            borrowing.EquipmentId,
            borrowing.DateBorrowed,
            borrowing.ExpectedReturnDate);

        _borrowings.Add(persisted);
        return Task.FromResult(persisted);
    }

    public Task UpdateAsync(Borrowing borrowing, CancellationToken cancellationToken = default)
    {
        // The stored instance is the same reference the caller mutated
        // (e.g. via MarkAsReturned), so there is nothing further to copy
        // here. A real store would use this method to write the change
        // through; kept explicit so the application layer never needs to
        // know the difference.
        var index = _borrowings.FindIndex(b => b.Id == borrowing.Id);
        if (index >= 0)
        {
            _borrowings[index] = borrowing;
        }

        return Task.CompletedTask;
    }
}
