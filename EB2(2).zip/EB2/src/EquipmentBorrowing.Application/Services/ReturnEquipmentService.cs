using EquipmentBorrowing.Application.Common;
using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Domain;

namespace EquipmentBorrowing.Application.Services;

/// <summary>
/// Executes the "Return Equipment" use case: finds the borrowing, checks
/// that it can actually be returned, marks it returned, and makes the
/// equipment available again.
///
/// Like <see cref="BorrowEquipmentService"/>, this coordinates Domain
/// objects through repository interfaces only — no persistence or
/// presentation concerns live here.
/// </summary>
public class ReturnEquipmentService
{
    private readonly IBorrowingRepository _borrowingRepository;
    private readonly IEquipmentRepository _equipmentRepository;

    public ReturnEquipmentService(
        IBorrowingRepository borrowingRepository,
        IEquipmentRepository equipmentRepository)
    {
        _borrowingRepository = borrowingRepository;
        _equipmentRepository = equipmentRepository;
    }

    public async Task<ReturnEquipmentResult> ExecuteAsync(
        ReturnEquipmentRequest request,
        CancellationToken cancellationToken = default)
    {
        var borrowing = await _borrowingRepository.GetByIdAsync(request.BorrowingId, cancellationToken);
        if (borrowing is null)
            return ReturnEquipmentResult.Failure(ReturnFailureReason.BorrowingNotFound);

        if (borrowing.Status == BorrowingStatus.Returned)
            return ReturnEquipmentResult.Failure(ReturnFailureReason.BorrowingAlreadyReturned);

        borrowing.MarkAsReturned(request.ReturnDate);
        await _borrowingRepository.UpdateAsync(borrowing, cancellationToken);

        // The equipment referenced by an active borrowing is expected to
        // still exist (this in-memory system never deletes equipment), but
        // the null check keeps the operation safe rather than assuming it.
        var equipment = await _equipmentRepository.GetByIdAsync(borrowing.EquipmentId, cancellationToken);
        if (equipment is not null)
        {
            equipment.MarkAsReturned();
            await _equipmentRepository.UpdateAsync(equipment, cancellationToken);
        }

        return ReturnEquipmentResult.Success(borrowing);
    }
}
