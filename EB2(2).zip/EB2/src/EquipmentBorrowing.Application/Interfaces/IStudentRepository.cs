using EquipmentBorrowing.Domain;

namespace EquipmentBorrowing.Application.Interfaces;

/// <summary>
/// Abstraction over wherever Student data actually lives (in-memory, a file,
/// a database, etc.). Exposes looking a student up by id, plus listing
/// everyone for display purposes (e.g. the student picker on the Borrow form).
/// </summary>
public interface IStudentRepository
{
    Task<Student?> GetByIdAsync(int id, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<Student>> GetAllAsync(CancellationToken cancellationToken = default);
}
