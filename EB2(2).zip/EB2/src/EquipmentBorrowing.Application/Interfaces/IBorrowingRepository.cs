using EquipmentBorrowing.Domain;

namespace EquipmentBorrowing.Application.Interfaces;

/// <summary>
/// Abstraction over wherever Borrowing records actually live. Exposes what
/// the Borrow Equipment use case needs (counting active borrowings,
/// persisting a new one), what the Return Equipment use case needs
/// (looking a borrowing up by id, persisting its returned status), and what
/// the Active Borrowings display needs (listing everything currently active).
/// </summary>
public interface IBorrowingRepository
{
    Task<int> CountActiveByStudentIdAsync(int studentId, CancellationToken cancellationToken = default);

    Task<Borrowing?> GetByIdAsync(int id, CancellationToken cancellationToken = default);

    /// <summary>
    /// All borrowings currently in the Active status, for display purposes
    /// (e.g. the "Active Borrowings" screen).
    /// </summary>
    Task<IReadOnlyList<Borrowing>> GetActiveAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Persists a new borrowing and returns the stored entity (with its
    /// assigned identity). The caller passes in a borrowing built with a
    /// placeholder id; the repository is responsible for assigning the real one.
    /// </summary>
    Task<Borrowing> AddAsync(Borrowing borrowing, CancellationToken cancellationToken = default);

    /// <summary>
    /// Persists a change to an existing borrowing (used after it is marked returned).
    /// </summary>
    Task UpdateAsync(Borrowing borrowing, CancellationToken cancellationToken = default);
}

