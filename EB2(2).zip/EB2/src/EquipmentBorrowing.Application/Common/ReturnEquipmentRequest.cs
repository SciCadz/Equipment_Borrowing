namespace EquipmentBorrowing.Application.Common;

/// <summary>
/// The input needed to attempt a return: which borrowing, and when it was returned.
/// </summary>
public record ReturnEquipmentRequest(int BorrowingId, DateOnly ReturnDate);
