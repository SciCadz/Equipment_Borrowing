using EquipmentBorrowing.Domain;

namespace EquipmentBorrowing.Application.Common;

/// <summary>
/// The specific rule that rejected a return request. "None" is used only for
/// a successful result and should never be inspected on its own.
/// </summary>
public enum ReturnFailureReason
{
    None,
    BorrowingNotFound,
    BorrowingAlreadyReturned
}

/// <summary>
/// Outcome of a Return Equipment attempt.
/// </summary>
public class ReturnEquipmentResult
{
    public bool IsSuccess { get; }
    public ReturnFailureReason FailureReason { get; }
    public Borrowing? Borrowing { get; }

    private ReturnEquipmentResult(bool isSuccess, ReturnFailureReason failureReason, Borrowing? borrowing)
    {
        IsSuccess = isSuccess;
        FailureReason = failureReason;
        Borrowing = borrowing;
    }

    public static ReturnEquipmentResult Success(Borrowing borrowing) =>
        new(true, ReturnFailureReason.None, borrowing);

    public static ReturnEquipmentResult Failure(ReturnFailureReason reason) =>
        new(false, reason, null);
}
