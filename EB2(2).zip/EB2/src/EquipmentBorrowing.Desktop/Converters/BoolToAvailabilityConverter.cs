using System.Globalization;
using Avalonia.Data.Converters;

namespace EquipmentBorrowing.Desktop.Converters;

/// <summary>
/// Turns Equipment.IsAvailable into the word a user should see, rather than
/// binding directly to the raw bool.
/// </summary>
public class BoolToAvailabilityConverter : IValueConverter
{
    public static readonly BoolToAvailabilityConverter Instance = new();

    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is bool isAvailable)
            return isAvailable ? "Available" : "Borrowed";

        return value;
    }

    public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException("This converter only supports one-way binding.");
}
