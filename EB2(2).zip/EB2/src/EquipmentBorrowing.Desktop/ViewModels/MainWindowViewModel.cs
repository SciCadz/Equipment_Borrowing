using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace EquipmentBorrowing.Desktop.ViewModels;

/// <summary>
/// Owns navigation between the application's two primary sections (Part J).
/// Both child ViewModels are created once by the DI container and kept
/// alive for the whole app run, so switching views never loses in-progress
/// state (a half-filled borrow form, an in-progress selection, etc.).
/// </summary>
public partial class MainWindowViewModel : ObservableObject
{
    public EquipmentViewModel EquipmentViewModel { get; }
    public BorrowingsViewModel BorrowingsViewModel { get; }

    [ObservableProperty]
    private ObservableObject currentViewModel;

    public MainWindowViewModel(EquipmentViewModel equipmentViewModel, BorrowingsViewModel borrowingsViewModel)
    {
        EquipmentViewModel = equipmentViewModel;
        BorrowingsViewModel = borrowingsViewModel;
        currentViewModel = equipmentViewModel;
    }

    [RelayCommand]
    private void ShowEquipment() => CurrentViewModel = EquipmentViewModel;

    [RelayCommand]
    private void ShowBorrowings() => CurrentViewModel = BorrowingsViewModel;
}
