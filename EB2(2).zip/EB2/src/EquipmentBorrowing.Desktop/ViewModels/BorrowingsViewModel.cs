using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using EquipmentBorrowing.Application.Common;
using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Application.Services;

namespace EquipmentBorrowing.Desktop.ViewModels;

/// <summary>
/// Backs the Active Borrowings screen: lists everything currently active,
/// and hands a return request to <see cref="ReturnEquipmentService"/>
/// (Part F). Like <see cref="EquipmentViewModel"/>, it never re-implements
/// the business rule about whether a borrowing can be returned.
/// </summary>
public partial class BorrowingsViewModel : ObservableObject, IRecipient<BorrowingStateChangedMessage>
{
    private readonly IBorrowingRepository _borrowingRepository;
    private readonly IEquipmentRepository _equipmentRepository;
    private readonly IStudentRepository _studentRepository;
    private readonly ReturnEquipmentService _returnEquipmentService;

    public ObservableCollection<BorrowingListItem> ActiveBorrowings { get; } = new();

    [ObservableProperty]
    private BorrowingListItem? selectedBorrowing;

    [ObservableProperty]
    private string? statusMessage;

    public BorrowingsViewModel(
        IBorrowingRepository borrowingRepository,
        IEquipmentRepository equipmentRepository,
        IStudentRepository studentRepository,
        ReturnEquipmentService returnEquipmentService)
    {
        _borrowingRepository = borrowingRepository;
        _equipmentRepository = equipmentRepository;
        _studentRepository = studentRepository;
        _returnEquipmentService = returnEquipmentService;

        WeakReferenceMessenger.Default.RegisterAll(this);

        _ = ReloadAsync();
    }

    public async Task ReloadAsync()
    {
        var activeBorrowings = await _borrowingRepository.GetActiveAsync();

        var items = new List<BorrowingListItem>();
        foreach (var borrowing in activeBorrowings.OrderBy(b => b.Id))
        {
            var student = await _studentRepository.GetByIdAsync(borrowing.StudentId);
            var equipment = await _equipmentRepository.GetByIdAsync(borrowing.EquipmentId);

            items.Add(new BorrowingListItem(
                borrowing.Id,
                student?.Name ?? $"Student #{borrowing.StudentId}",
                equipment?.Name ?? $"Equipment #{borrowing.EquipmentId}",
                borrowing.DateBorrowed,
                borrowing.ExpectedReturnDate));
        }

        ActiveBorrowings.Clear();
        foreach (var item in items)
            ActiveBorrowings.Add(item);
    }

    [RelayCommand]
    private async Task ReturnAsync()
    {
        if (SelectedBorrowing is null)
        {
            StatusMessage = "Please select a borrowing to return.";
            return;
        }

        var request = new ReturnEquipmentRequest(SelectedBorrowing.Id, DateOnly.FromDateTime(DateTime.Today));
        var result = await _returnEquipmentService.ExecuteAsync(request);

        StatusMessage = result.IsSuccess
            ? $"Borrowing #{result.Borrowing!.Id} returned."
            : DescribeFailure(result.FailureReason);

        if (result.IsSuccess)
        {
            await ReloadAsync();
            WeakReferenceMessenger.Default.Send(new BorrowingStateChangedMessage());
        }
    }

    private static string DescribeFailure(ReturnFailureReason reason) => reason switch
    {
        ReturnFailureReason.BorrowingNotFound => "That borrowing could not be found.",
        ReturnFailureReason.BorrowingAlreadyReturned => "That borrowing has already been returned.",
        _ => "The return request could not be completed."
    };

    /// <summary>
    /// Called when the Equipment screen completes a borrow, so a newly
    /// created active borrowing shows up here without polling.
    /// </summary>
    public void Receive(BorrowingStateChangedMessage message) => _ = ReloadAsync();
}
