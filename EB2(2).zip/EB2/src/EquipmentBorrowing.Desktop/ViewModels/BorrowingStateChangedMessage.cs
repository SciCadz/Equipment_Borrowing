namespace EquipmentBorrowing.Desktop.ViewModels;

/// <summary>
/// Broadcast through CommunityToolkit.Mvvm's messenger whenever a borrow or
/// a return succeeds, so any other open view can refresh its own data
/// without the ViewModels needing a direct reference to each other.
/// </summary>
public sealed record BorrowingStateChangedMessage;
