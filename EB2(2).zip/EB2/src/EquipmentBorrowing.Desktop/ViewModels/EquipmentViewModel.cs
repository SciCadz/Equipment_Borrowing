using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using EquipmentBorrowing.Application.Common;
using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Application.Services;
using EquipmentBorrowing.Domain;

namespace EquipmentBorrowing.Desktop.ViewModels;

/// <summary>
/// Backs the Equipment screen: lists equipment (Part D) and collects the
/// input for a borrow request, then hands the actual decision off to
/// <see cref="BorrowEquipmentService"/> (Part E). This class never
/// re-implements eligibility/availability/limit checks itself - it only
/// gathers input, calls the service, and reports whatever the service says.
/// </summary>
public partial class EquipmentViewModel : ObservableObject, IRecipient<BorrowingStateChangedMessage>
{
    private readonly IEquipmentRepository _equipmentRepository;
    private readonly IStudentRepository _studentRepository;
    private readonly BorrowEquipmentService _borrowEquipmentService;

    public ObservableCollection<Equipment> EquipmentList { get; } = new();
    public ObservableCollection<Student> Students { get; } = new();

    [ObservableProperty]
    private Equipment? selectedEquipment;

    [ObservableProperty]
    private Student? selectedStudent;

    [ObservableProperty]
    private DateTimeOffset? expectedReturnDate = DateTimeOffset.Now.Date.AddDays(7);

    [ObservableProperty]
    private string? statusMessage;

    public EquipmentViewModel(
        IEquipmentRepository equipmentRepository,
        IStudentRepository studentRepository,
        BorrowEquipmentService borrowEquipmentService)
    {
        _equipmentRepository = equipmentRepository;
        _studentRepository = studentRepository;
        _borrowEquipmentService = borrowEquipmentService;

        WeakReferenceMessenger.Default.RegisterAll(this);

        // Fire-and-forget: the view starts empty and populates itself as
        // soon as this completes, which is effectively instant against the
        // in-memory repositories.
        _ = ReloadAsync();
    }

    public async Task ReloadAsync()
    {
        var equipment = await _equipmentRepository.GetAllAsync();
        EquipmentList.Clear();
        foreach (var item in equipment.OrderBy(e => e.Id))
            EquipmentList.Add(item);

        if (Students.Count == 0)
        {
            var students = await _studentRepository.GetAllAsync();
            foreach (var student in students.OrderBy(s => s.Id))
                Students.Add(student);
        }
    }

    [RelayCommand]
    private async Task BorrowAsync()
    {
        // --- Presentation validation: nothing about eligibility here,
        // only "did the user give us enough to even try." ---
        if (SelectedStudent is null)
        {
            StatusMessage = "Please select a student.";
            return;
        }

        if (SelectedEquipment is null)
        {
            StatusMessage = "Please select a piece of equipment.";
            return;
        }

        if (ExpectedReturnDate is null)
        {
            StatusMessage = "Please select an expected return date.";
            return;
        }

        if (ExpectedReturnDate.Value.Date < DateTime.Today)
        {
            StatusMessage = "The expected return date cannot be in the past.";
            return;
        }

        var request = new BorrowEquipmentRequest(
            SelectedStudent.Id,
            SelectedEquipment.Id,
            DateOnly.FromDateTime(DateTime.Today),
            DateOnly.FromDateTime(ExpectedReturnDate.Value.Date));

        // --- Business validation happens entirely inside the service. ---
        var result = await _borrowEquipmentService.ExecuteAsync(request);

        StatusMessage = result.IsSuccess
            ? $"Borrowing #{result.Borrowing!.Id} approved. Due {result.Borrowing.ExpectedReturnDate:yyyy-MM-dd}."
            : DescribeFailure(result.FailureReason);

        if (result.IsSuccess)
        {
            await ReloadAsync();
            WeakReferenceMessenger.Default.Send(new BorrowingStateChangedMessage());
        }
    }

    private static string DescribeFailure(BorrowFailureReason reason) => reason switch
    {
        BorrowFailureReason.StudentNotFound => "That student could not be found.",
        BorrowFailureReason.StudentNotAllowedToBorrow => "This student is not currently allowed to borrow equipment.",
        BorrowFailureReason.EquipmentNotFound => "That equipment could not be found.",
        BorrowFailureReason.EquipmentNotAvailable => "That equipment is currently unavailable.",
        BorrowFailureReason.BorrowingLimitReached => "This student has reached their active borrowing limit.",
        _ => "The borrowing request could not be completed."
    };

    /// <summary>
    /// Called when the Active Borrowings screen completes a return, so this
    /// screen's availability list stays correct without polling.
    /// </summary>
    public void Receive(BorrowingStateChangedMessage message) => _ = ReloadAsync();
}
