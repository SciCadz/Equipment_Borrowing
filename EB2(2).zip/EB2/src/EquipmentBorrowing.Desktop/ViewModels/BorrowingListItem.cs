namespace EquipmentBorrowing.Desktop.ViewModels;

/// <summary>
/// A single row for the Active Borrowings list. This is a presentation
/// projection, not a domain model - it exists only because a Borrowing
/// record stores StudentId/EquipmentId, and the screen needs to show
/// names instead of ids. Populated fresh on every reload rather than kept
/// in sync live, so it doesn't need to be observable itself.
/// </summary>
public class BorrowingListItem
{
    public int Id { get; }
    public string StudentName { get; }
    public string EquipmentName { get; }
    public DateOnly DateBorrowed { get; }
    public DateOnly ExpectedReturnDate { get; }

    public BorrowingListItem(
        int id,
        string studentName,
        string equipmentName,
        DateOnly dateBorrowed,
        DateOnly expectedReturnDate)
    {
        Id = id;
        StudentName = studentName;
        EquipmentName = equipmentName;
        DateBorrowed = dateBorrowed;
        ExpectedReturnDate = expectedReturnDate;
    }
}
