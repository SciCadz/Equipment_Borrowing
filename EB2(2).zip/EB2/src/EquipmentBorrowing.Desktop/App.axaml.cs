using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Application.Services;
using EquipmentBorrowing.Desktop.ViewModels;
using EquipmentBorrowing.Domain;
using EquipmentBorrowing.Infrastructure.Repositories;
using Microsoft.Extensions.DependencyInjection;

namespace EquipmentBorrowing.Desktop;

public partial class App : Avalonia.Application
{
    public static IServiceProvider Services { get; private set; } = null!;

    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        var services = new ServiceCollection();
        ConfigureServices(services);
        Services = services.BuildServiceProvider();

        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            // MainWindowViewModel (and, transitively, EquipmentViewModel and
            // BorrowingsViewModel) is resolved here rather than "new"-ed up -
            // this is the one place in the app that knows how the object
            // graph is wired together.
            desktop.MainWindow = new MainWindow
            {
                DataContext = Services.GetRequiredService<MainWindowViewModel>()
            };
        }

        base.OnFrameworkInitializationCompleted();
    }

    /// <summary>
    /// The single composition point for the application (Part H). Every
    /// repository, service, and ViewModel is registered here, once, and
    /// everything else receives its dependencies through its constructor -
    /// nothing below this method ever calls "new" on a repository or service.
    /// </summary>
    private static void ConfigureServices(IServiceCollection services)
    {
        // Repositories are singletons: because they are in-memory, the
        // instance itself IS the application's state for this run. If they
        // were re-created per view, switching between Equipment and Active
        // Borrowings would silently reset everything.
        services.AddSingleton<IStudentRepository>(_ => new InMemoryStudentRepository(SeedStudents()));
        services.AddSingleton<IEquipmentRepository>(_ => new InMemoryEquipmentRepository(SeedEquipment()));
        services.AddSingleton<IBorrowingRepository, InMemoryBorrowingRepository>();

        services.AddTransient<BorrowEquipmentService>();
        services.AddTransient<ReturnEquipmentService>();

        services.AddTransient<EquipmentViewModel>();
        services.AddTransient<BorrowingsViewModel>();
        services.AddTransient<MainWindowViewModel>();
    }

    private static IEnumerable<Student> SeedStudents() => new[]
    {
        new Student(1, "Juan Dela Cruz", isAllowedToBorrow: true, maxActiveBorrowings: 3),
        new Student(2, "Maria Santos", isAllowedToBorrow: true, maxActiveBorrowings: 2),
        new Student(3, "Pedro Reyes", isAllowedToBorrow: false)
    };

    private static IEnumerable<Equipment> SeedEquipment() => new[]
    {
        new Equipment(100, "Digital Multimeter"),
        new Equipment(101, "Oscilloscope"),
        new Equipment(102, "Function Generator"),
        new Equipment(103, "Soldering Iron"),
        new Equipment(104, "Logic Analyzer")
    };
}
