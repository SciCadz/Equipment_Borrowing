using Avalonia;

namespace EquipmentBorrowing.Desktop;

internal static class Program
{
    // Avalonia needs a static Main, and this one shouldn't run before
    // AppBuilder is set up (that happens in BuildAvaloniaApp below).
    [STAThread]
    public static void Main(string[] args) =>
        BuildAvaloniaApp()
            .StartWithClassicDesktopLifetime(args);

    public static AppBuilder BuildAvaloniaApp() =>
        AppBuilder.Configure<App>()
            .UsePlatformDetect()
            .LogToTrace();
}
