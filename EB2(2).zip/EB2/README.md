# Campus Equipment Borrowing System

Laboratory Activity 1 — From Requirements to Application Structure.

This repository contains the architectural foundation for the system (Domain,
Application, Infrastructure, Tests) with one fully implemented use case,
**Borrow Equipment**, demonstrated both by a console program and by an
automated test suite. No database and no graphical interface are included,
per the activity's scope.

---

## Part A — Analysis

### A. Actors

| Actor | What they expect from the system |
|---|---|
| **Student** | To be able to request equipment and immediately know whether the request is approved or denied, and why. |
| **Laboratory Staff / Custodian** (implied) | To trust that the system enforces borrowing rules correctly, so equipment inventory and student borrowing history stay accurate without manual checking. |

The scenario describes only one active initiator of requests (the Student);
laboratory staff are an implied actor because someone is ultimately
responsible for the equipment records the system protects, even though the
scenario does not describe a staff-facing action.

### B. Use Cases

| Item | Description |
|---|---|
| Use Case | **Borrow Equipment** |
| Primary Actor | Student |
| Preconditions | Student is registered and currently allowed to borrow; equipment catalog exists. |
| Main Action | Student requests to borrow a specific, available piece of equipment. |
| Expected Result | A new borrowing record is created with status Active; the equipment becomes unavailable. |
| Possible Failure | Student not allowed to borrow, equipment not found, equipment unavailable, or student already at the maximum number of active borrowings. |

| Item | Description |
|---|---|
| Use Case | **Return Equipment** |
| Primary Actor | Student |
| Preconditions | An Active borrowing record exists linking the student to the equipment. |
| Main Action | Student returns the borrowed equipment. |
| Expected Result | The borrowing is marked Returned; the equipment becomes available again. |
| Possible Failure | No matching active borrowing exists for that student/equipment pair (e.g. already returned). |

| Item | Description |
|---|---|
| Use Case | **Find Available Equipment** |
| Primary Actor | Student |
| Preconditions | Equipment catalog exists. |
| Main Action | Student browses or searches for equipment that is currently available. |
| Expected Result | A list of equipment currently marked available is returned. |
| Possible Failure | No equipment currently matches the availability filter (an empty result, not necessarily an error). |

> Only **Borrow Equipment** is implemented in this activity, as instructed in
> Part E. Return Equipment and Find Available Equipment are documented here
> because they were used in Part A/D to reason about what the domain models
> and repositories need to support later, but their application services and
> supporting repository methods are intentionally left out of this
> submission so that no interface method exists without a use case that
> currently needs it.

### C. Domain Concepts

**Student**
1. Must contain: identity, name, whether currently allowed to borrow, and the maximum number of active borrowings permitted.
2. Rules/state it owns: its own eligibility flag; the borrowing-limit *policy* value.
3. Not its responsibility: tracking which specific items it currently has borrowed (that is a fact about `Borrowing` records, queried when needed, not duplicated state that could go stale), or deciding whether a particular request should be approved (that requires looking at `Equipment` too, which is beyond what a `Student` alone can know).

**Equipment**
1. Must contain: identity, name, and current availability.
2. Rules/state it owns: the transition between available and borrowed (it can validate that it isn't already borrowed before allowing that transition).
3. Not its responsibility: knowing who currently has it or for how long (that belongs to `Borrowing`), or deciding eligibility (that depends on the `Student`).

**Borrowing**
1. Must contain: which student, which equipment, the date borrowed, the expected return date, the actual return date (once returned), and its status.
2. Rules/state it owns: the Active → Returned transition, and the invariant that the expected return date cannot precede the borrow date.
3. Not its responsibility: deciding whether it should have been created in the first place (that is the application service's job, since it needs the `Student`, the `Equipment`, and the count of other `Borrowing` records together).

---

## Part I — Architecture Explanation

### 1. Solution Structure

- **Domain** — the concepts and rules that exist regardless of how the
  system is built or deployed: `Student`, `Equipment`, `Borrowing`,
  `BorrowingStatus`. No dependency on any other project.
- **Application** — the use cases the system performs, expressed as
  services (`BorrowEquipmentService`) that coordinate Domain objects through
  repository *interfaces* (`IStudentRepository`, `IEquipmentRepository`,
  `IBorrowingRepository`), plus the request/result types those services use.
  Depends only on Domain.
- **Infrastructure** — concrete, swappable implementations of the
  Application-layer interfaces. For this activity, three in-memory
  repositories (`InMemoryStudentRepository`, `InMemoryEquipmentRepository`,
  `InMemoryBorrowingRepository`). Depends on Domain and Application.
- **Tests** — automated tests for `BorrowEquipmentService`, covering the
  successful path and every failure rule. Depends on all three projects
  above, the same way a future UI would.

A separate `EquipmentBorrowing.ConsoleDemo` project is included under `src/`
as the "minimal executable program" required by Part H — it wires the
in-memory repositories to the service and prints one successful and several
unsuccessful borrowing attempts to the console.

### 2. Dependency Direction

```text
ConsoleDemo / Tests / Future Avalonia UI
          │
          ▼
     Application  ───uses interfaces implemented by───▶  (implemented in Infrastructure)
       │      ▲
       ▼      │
     Domain   │
              │
     Infrastructure
```

Application depends on Domain, and defines the repository *interfaces*.
Infrastructure depends on both Domain and Application, because it must
implement Application's interfaces using Domain's types — but Application
never references Infrastructure. This is what allows the storage mechanism
to change later without touching the business logic: Application only knows
about `IEquipmentRepository`, never `InMemoryEquipmentRepository` or any
future `SqliteEquipmentRepository`.

### 3. Use Case Mapping

```text
Actor:                          Student
Use Case:                       Borrow Equipment
Application Service:            BorrowEquipmentService
Domain Objects Used:            Student, Equipment, Borrowing, BorrowingStatus
Repository Interfaces Used:     IStudentRepository, IEquipmentRepository, IBorrowingRepository
Infrastructure Implementations: InMemoryStudentRepository, InMemoryEquipmentRepository, InMemoryBorrowingRepository
```

### 4. Reflection

**1. Why should the application service depend on a repository interface
instead of directly depending on a database implementation?**
Because the business rules for borrowing equipment (is the student allowed,
is the equipment available, has the limit been reached) have nothing to do
with *how* that data is stored. Depending on an interface means
`BorrowEquipmentService` can be tested with an in-memory fake today and
handed a SQLite-backed implementation later without a single line of the
service itself changing.

**2. Which parts of your current solution could remain unchanged if SQLite
were added later?**
All of Domain and Application. Only Infrastructure would change — the three
`InMemory...Repository` classes would be replaced (or supplemented) by
implementations that talk to SQLite, still satisfying the same three
interfaces.

**3. Which project would eventually contain Avalonia Views?**
A new UI project (e.g. `EquipmentBorrowing.Desktop`) sitting alongside
`ConsoleDemo`, at the same "outer" layer — it would reference Application
(to call `BorrowEquipmentService`) and Domain (to display the data returned),
but Infrastructure would only need to be referenced at startup to wire up
concrete repositories via dependency injection.

**4. Should an Avalonia button directly execute database queries? Why or
why not?**
No. If a button's click handler executed SQL directly, the business rules
(eligibility, availability, borrowing limits) would either have to live in
the UI code or be duplicated everywhere a similar action is triggered. Routing
the click handler through `BorrowEquipmentService` instead keeps the rules in
one place, keeps the UI free of persistence concerns, and keeps the logic
testable without launching a UI at all.

**5. What part of your implementation represents the actual business
operation requested by the actor?**
`BorrowEquipmentService.ExecuteAsync`. It is the one piece of code that
represents "a student borrowing equipment" as a whole — everything else
(the domain models, the repository interfaces, the in-memory
implementations) exists to support that single operation.

---

## Running the Demonstration

`Domain`, `Application`, `Infrastructure`, and `ConsoleDemo` have been built
and run successfully with the .NET 8 SDK (0 warnings, 0 errors):

```bash
dotnet build src/EquipmentBorrowing.ConsoleDemo/EquipmentBorrowing.ConsoleDemo.csproj
dotnet run --project src/EquipmentBorrowing.ConsoleDemo
```

This prints one approved borrowing followed by four denied attempts
(equipment not found, equipment unavailable, student not allowed to borrow,
and student at the borrowing limit) — confirmed output:

```text
--- Successful borrow ---
APPROVED: Borrowing #1 — student 1 borrowed equipment 100, due 2026-09-04.

--- Failure - equipment does not exist ---
DENIED: EquipmentNotFound

--- Failure - equipment is unavailable ---
DENIED: EquipmentNotAvailable

--- Failure - student is not allowed to borrow ---
DENIED: StudentNotAllowedToBorrow

--- Failure - student reached the active borrowing limit ---
DENIED: BorrowingLimitReached
```

`tests/EquipmentBorrowing.Tests` could **not** be restored/verified in the
environment this was prepared in, because its `xunit` and
`Microsoft.NET.Test.Sdk` packages need `api.nuget.org`, which that sandbox
could not reach (403 Forbidden, no local mirror available). Run it yourself
on a machine with normal internet access:

```bash
dotnet test
```

It should run six tests — the same success case and every failure rule
individually — with the same outcomes already confirmed above via the
console demo. If it doesn't pass, the test code and the service logic are in
the same repo to compare line-by-line.

Still needed for submission: the required screenshot of a successful
`dotnet build` (including the test project, once you have NuGet access) and
confirmation that `dotnet test` passes on your machine.

---

# Laboratory Activity 2 — Avalonia UI and MVVM

Everything below extends the Laboratory Activity 1 explanation above rather
than replacing it. The Domain, Application, Infrastructure, and Tests
projects described above are unchanged in their responsibilities; a small
number of repository interface methods were added (see the Updated
Architecture section) purely to support displaying data and returning
equipment — no existing method signature or business rule changed.

## 1. Desktop Project

`EquipmentBorrowing.Desktop` is the presentation layer added in this
activity. It is responsible for everything the earlier layers deliberately
avoid: displaying information, collecting input, holding presentation state,
and giving the user feedback. It contains:

- **`App.axaml` / `App.axaml.cs`** — the application's composition root
  (Part H). This is the *only* place in the entire solution that constructs
  a repository or a service directly; everywhere else receives them through
  a constructor. It also declares the DataTemplates that map each
  ViewModel type to the View that should render it, and the shared styles
  used across both screens.
- **`MainWindow.axaml`** — the app shell: a navigation panel on the left,
  and a content area that shows whichever ViewModel is currently selected.
- **`Views/`** — `EquipmentView` and `BorrowingsView`, XAML only. They
  contain layout, controls, bindings, and styling — no business logic and
  no direct repository access.
- **`ViewModels/`** — `EquipmentViewModel`, `BorrowingsViewModel`, and
  `MainWindowViewModel`, built with `CommunityToolkit.Mvvm`. They hold
  presentation state and commands, and call `BorrowEquipmentService` /
  `ReturnEquipmentService` for the two operations from Laboratory Activity 1
  — never reimplementing the rules those services already enforce.
- **`Converters/`** — `BoolToAvailabilityConverter`, a small presentation-only
  helper that turns `Equipment.IsAvailable` into readable text.

Desktop references `Application` and `Infrastructure` (to compose the
dependency graph at startup) and, transitively, `Domain`. **Domain and
Application reference nothing from Avalonia** — they were not touched to
accommodate the UI, only extended (see below) where the UI genuinely needed
new read operations.

## 2. Updated Architecture

```text
Avalonia View (EquipmentView / BorrowingsView)
      │
      │  Binding / Command
      ▼
ViewModel (EquipmentViewModel / BorrowingsViewModel / MainWindowViewModel)
      │
      │  Application Operation
      ▼
Application Service (BorrowEquipmentService / ReturnEquipmentService)
      │
      ├──────────────► Domain (Student, Equipment, Borrowing)
      │
      ▼
Repository Interface (IStudentRepository / IEquipmentRepository / IBorrowingRepository)
      ▲
      │
Infrastructure Implementation (InMemory*Repository)
```

ViewModels hold two kinds of dependencies, injected through their
constructors:

- **Repository interfaces**, used only to *read* data for display (listing
  equipment, listing students, listing active borrowings). This is
  presentation composition, not a business decision, so it does not need to
  go through an application service.
- **Application services**, used for the two *operations* that carry real
  business rules: borrowing and returning. These always go through
  `BorrowEquipmentService` / `ReturnEquipmentService`, never straight to a
  repository.

To support the two points above, the repository interfaces gained a small
number of read-only methods that did not exist after Laboratory Activity 1:
`IStudentRepository.GetAllAsync`, `IEquipmentRepository.GetAllAsync`, and
`IBorrowingRepository.GetByIdAsync` / `GetActiveAsync` / `UpdateAsync`. Every
existing method and every existing business rule is unchanged.

## 3. Borrow Equipment Flow

1. The user opens the **Equipment** screen. `EquipmentViewModel` was already
   constructed by the DI container with `IEquipmentRepository`,
   `IStudentRepository`, and `BorrowEquipmentService` injected; its
   constructor kicks off `ReloadAsync()`, which populates the equipment list
   and student list from the repositories.
2. The user selects a student, selects a piece of equipment from the list
   (bound via `SelectedEquipment`), and picks an expected return date.
3. The user presses **Borrow Equipment**, which is bound to
   `EquipmentViewModel.BorrowCommand` (a `[RelayCommand]`-generated
   `AsyncRelayCommand`).
4. The command first runs presentation validation only: is a student
   selected, is equipment selected, is the date present and not in the past.
   If any of that fails, it sets `StatusMessage` and returns — it never
   reaches the service.
5. If presentation validation passes, it builds a `BorrowEquipmentRequest`
   and awaits `BorrowEquipmentService.ExecuteAsync(request)`. This is the
   only place business rules are evaluated (student eligibility, equipment
   availability, borrowing limit) — exactly the same service, unmodified,
   from Laboratory Activity 1.
6. The result comes back as a `BorrowEquipmentResult`. On success,
   `StatusMessage` shows the confirmation and due date, the equipment list
   is reloaded (so the borrowed item now shows "Borrowed"), and a
   `BorrowingStateChangedMessage` is broadcast. On failure, `StatusMessage`
   shows a message specific to the `BorrowFailureReason` returned.
7. `BorrowingsViewModel`, having registered itself as a recipient of
   `BorrowingStateChangedMessage`, receives that broadcast and reloads
   itself — so the new borrowing shows up on the Active Borrowings screen
   without the user needing to switch away and back.

## 4. Return Equipment Flow

1. The user opens the **Active Borrowings** screen. `BorrowingsViewModel`
   loads active borrowings from `IBorrowingRepository.GetActiveAsync()` and,
   for each one, resolves the student and equipment names to build a
   `BorrowingListItem` for display (a presentation-only projection — not a
   new domain model).
2. The user selects a row (`SelectedBorrowing`) and presses **Return
   Selected**, bound to `BorrowingsViewModel.ReturnCommand`.
3. Presentation validation: if nothing is selected, `StatusMessage` says so
   and the command returns without calling the service.
4. Otherwise it builds a `ReturnEquipmentRequest` and awaits
   `ReturnEquipmentService.ExecuteAsync(request)`. The service looks the
   borrowing up, checks it hasn't already been returned, marks it Returned,
   and makes the equipment available again — all inside the Application
   layer, none of it in the ViewModel.
5. On success, `StatusMessage` confirms the return, the borrowings list is
   reloaded (the returned item disappears from "active"), and a
   `BorrowingStateChangedMessage` is broadcast. On failure (borrowing not
   found, or already returned), `StatusMessage` shows the specific reason.
6. `EquipmentViewModel` receives that same broadcast and reloads itself, so
   the equipment immediately shows "Available" again on the Equipment
   screen.

## 5. Architectural Reflection

**Why should the View not call a repository directly?**
The View's job is layout and binding, not deciding what data means or
whether an operation is allowed. If `EquipmentView.axaml.cs` called
`IEquipmentRepository` directly, the same lookup logic would eventually be
duplicated across every View that needs equipment data, and there would be
no single place left to add a business rule later without touching XAML
code-behind.

**Why should business rules not be implemented in the ViewModel?**
Because then the rule would only exist for whichever View happens to call
it. Laboratory Activity 1 exists specifically so "is this equipment
available," "is this student allowed to borrow," and "has the limit been
reached" have exactly one implementation, usable from a console app, a test
suite, or this desktop UI without being rewritten for each one. Duplicating
that logic in a ViewModel risks the UI and the console demo disagreeing
about what counts as a valid borrowing.

**What is the responsibility of the ViewModel?**
To hold presentation state (selected items, typed-in values, status
messages), expose it and commands to the View through bindings, and
translate a user action into a call to the appropriate application service
— then translate the result back into something displayable. Nothing more.

**Why can the existing Application layer work without knowing that Avalonia
is being used?**
Because `BorrowEquipmentService` and `ReturnEquipmentService` depend only on
repository *interfaces* and Domain types, both defined in projects that
don't reference Avalonia. The Desktop project depends on Application, not
the other way around — Application has no idea anything is even displaying
its results.

**What advantage is gained from registering dependencies in one composition
point?**
`App.axaml.cs` is the only place that needs to know the concrete types
(`InMemoryEquipmentRepository`, etc.) behind each interface. Every
ViewModel and service just asks for an interface through its constructor,
so replacing an in-memory repository with a real one later means editing
one method (`ConfigureServices`), not every class that happens to use it.

**If the in-memory repository were replaced by SQLite later, which parts of
the current interface should remain largely unchanged?**
All three Views, all three ViewModels, and both application services.
Only the `ConfigureServices` registrations in `App.axaml.cs` would change
(swapping `InMemoryEquipmentRepository` for a SQLite-backed implementation
of the same interface), plus a new Infrastructure project/class to hold
that implementation.

## Running the Desktop Application

This could **not** be built or run in the sandbox this was prepared in —
the Avalonia, CommunityToolkit.Mvvm, and Microsoft.Extensions.DependencyInjection
NuGet packages all need `api.nuget.org`, which returned the same 403
Forbidden already noted above for the test project. Unlike the Lab 1
console demo (which built and ran successfully because its packages needed
no external NuGet access), **none of the Desktop project's XAML or C# has
been compiler-verified.** It was written carefully against standard Avalonia
11 / CommunityToolkit.Mvvm 8 patterns, but please build it early and tell me
immediately if anything doesn't compile — that's very possible for
hand-written XAML that's never been through a compiler.

```bash
dotnet restore
dotnet build
dotnet run --project src/EquipmentBorrowing.Desktop
```

Expected behavior once running:
- The window opens on the **Equipment** screen with five seeded equipment
  items and three seeded students.
- Selecting a student, an available piece of equipment, and a date, then
  pressing **Borrow Equipment**, should approve the borrowing and gray it
  out in the list.
- Switching to **Active Borrowings** should show that new borrowing.
  Selecting it and pressing **Return Selected** should remove it from the
  list and make the equipment available again back on the Equipment screen.
- Trying to borrow with nothing selected, or borrowing equipment that's
  already unavailable, should show a message instead of silently doing
  nothing.

Still needed for submission (Lab 2): screenshots of the running app, a
successful borrow, a successful return, at least one handled failure, and a
successful `dotnet build` including the Desktop project.

