using EquipmentBorrowing.Application.Common;
using EquipmentBorrowing.Application.Services;
using EquipmentBorrowing.Domain;
using EquipmentBorrowing.Infrastructure.Repositories;
using Xunit;

namespace EquipmentBorrowing.Tests;

public class ReturnEquipmentServiceTests
{
    private static readonly DateOnly DateBorrowed = new(2026, 8, 28);
    private static readonly DateOnly ExpectedReturnDate = new(2026, 9, 4);
    private static readonly DateOnly ActualReturnDate = new(2026, 9, 2);

    private static async Task<(ReturnEquipmentService Service, InMemoryEquipmentRepository EquipmentRepository, int BorrowingId)>
        CreateServiceWithExistingBorrowingAsync()
    {
        var equipmentRepository = new InMemoryEquipmentRepository(
            new[] { new Equipment(100, "Digital Multimeter") });

        var borrowingRepository = new InMemoryBorrowingRepository();

        var borrowService = new BorrowEquipmentService(
            new InMemoryStudentRepository(new[] { new Student(1, "Juan Dela Cruz") }),
            equipmentRepository,
            borrowingRepository);

        var borrowResult = await borrowService.ExecuteAsync(
            new BorrowEquipmentRequest(1, 100, DateBorrowed, ExpectedReturnDate));

        var returnService = new ReturnEquipmentService(borrowingRepository, equipmentRepository);

        return (returnService, equipmentRepository, borrowResult.Borrowing!.Id);
    }

    [Fact]
    public async Task ExecuteAsync_ReturnsBorrowing_WhenBorrowingIsActive()
    {
        var (service, equipmentRepository, borrowingId) = await CreateServiceWithExistingBorrowingAsync();

        var result = await service.ExecuteAsync(new ReturnEquipmentRequest(borrowingId, ActualReturnDate));

        Assert.True(result.IsSuccess);
        Assert.Equal(BorrowingStatus.Returned, result.Borrowing!.Status);
        Assert.Equal(ActualReturnDate, result.Borrowing.ActualReturnDate);

        var storedEquipment = await equipmentRepository.GetByIdAsync(100);
        Assert.True(storedEquipment!.IsAvailable);
    }

    [Fact]
    public async Task ExecuteAsync_Fails_WhenBorrowingDoesNotExist()
    {
        var (service, _, _) = await CreateServiceWithExistingBorrowingAsync();

        var result = await service.ExecuteAsync(new ReturnEquipmentRequest(999, ActualReturnDate));

        Assert.False(result.IsSuccess);
        Assert.Equal(ReturnFailureReason.BorrowingNotFound, result.FailureReason);
    }

    [Fact]
    public async Task ExecuteAsync_Fails_WhenBorrowingHasAlreadyBeenReturned()
    {
        var (service, _, borrowingId) = await CreateServiceWithExistingBorrowingAsync();

        var first = await service.ExecuteAsync(new ReturnEquipmentRequest(borrowingId, ActualReturnDate));
        Assert.True(first.IsSuccess);

        var second = await service.ExecuteAsync(new ReturnEquipmentRequest(borrowingId, ActualReturnDate));

        Assert.False(second.IsSuccess);
        Assert.Equal(ReturnFailureReason.BorrowingAlreadyReturned, second.FailureReason);
    }
}
