# Lab 3 — what to do (in order)

This folder is your Lab 2 project (EB2) with the Lab 3 changes already applied. **It has not been compiled or run**
(the tool that produced it had no .NET SDK). Expect to fix a small compile error or two.

## Files changed or added
Added (Infrastructure): `Persistence/EquipmentBorrowingDbContext.cs`, `Persistence/SeedData.cs`, `Persistence/DesignTimeDbContextFactory.cs`,
`Persistence/Configurations/{Student,Equipment,Borrowing}Configuration.cs`, `Repositories/Ef{Student,Equipment,Borrowing}Repository.cs`,
`Repositories/EfBorrowingQueries.cs`, `DependencyInjection.cs`
Added (Application): `Interfaces/IBorrowingQueries.cs`, `Common/ActiveBorrowingDetails.cs`
Added (other): `tests/.../EfPersistenceTests.cs`, `docs/database-queries.sql`, `docs/database-diagram.png`
Changed: `IEquipmentRepository` (+`GetAvailableAsync`), `InMemoryEquipmentRepository` (implements it), both `.csproj` (EF Core packages),
`App.axaml.cs`, `BorrowingsViewModel.cs`, `EquipmentViewModel.cs`, `EquipmentView.axaml`, `.gitignore`, `README.md` (Lab 3 section appended)

## Steps (commit after each — the lab requires meaningful Git history over two weeks, from BOTH partners)
1. Put this project into your Git repo (see "Repo note" below). `git checkout -b lab3-persistence`.
2. `dotnet restore` then `dotnet build`. Fix anything that does not compile.   -> commit "Add SQLite and EF Core packages"
3. Review `docs/` diagram and `Persistence/Configurations`.                    -> commit "Design relational database schema / Configure entity relationships"
4. Create the migration (commands are in README section 5).                    -> commit "Create initial database migration" (commit the `Migrations/` folder)
5. `dotnet ef database update`; open the generated `equipmentborrowing.design.db` in DB Browser for SQLite: screenshot the tables.
6. `dotnet test` — the Lab 1/2 tests should still pass, plus the new `EfPersistenceTests` (they need the migration from step 4).
7. `dotnet run --project src/EquipmentBorrowing.Desktop`: run the persistence demonstration (README section 8) and take the screenshots;
   copy the real SQL from the terminal into README section 6.
8. Open `%LocalAppData%\EquipmentBorrowing\equipmentborrowing.db` in DB Browser, run `docs/database-queries.sql`, screenshot the data.
9. Fill in the README placeholders, rewrite the reflection answers in your own words.

## Repo note
The GitHub repo (SciCadz/Equipment_Borrowing) currently contains Lab 1 only, plus an `EB2(2).zip`. Lab 3 must continue the same repo
*with* the Desktop project, so unzip this folder's contents into the repo root (replacing the Lab 1 files), delete the stray zip file, and commit.

## Things to double-check when you build
- Package versions: the code uses EF Core 8.0.11 on net8.0. Keep all EF packages on the same version.
- If `dotnet ef` says it cannot create the DbContext: run `dotnet build` first and check the `--project` / `--startup-project` paths.
- If the app shows "no such table": the migration was not created, or `Services.InitializeDatabase()` did not run.
- Delete `%LocalAppData%\EquipmentBorrowing\equipmentborrowing.db` only if you want a fresh database (e.g. after changing seed data and adding a new migration). Do not do this in your final demonstration.
