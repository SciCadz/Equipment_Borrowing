-- ITSD 81 Laboratory Activity 3 - database-queries.sql
-- SQLite dialect. Run in DB Browser for SQLite (or DBeaver) against:
--   %LocalAppData%\EquipmentBorrowing\equipmentborrowing.db
-- Table / column names come from the EF Core configuration:
--   Students   (Id, Name, IsAllowedToBorrow, MaxActiveBorrowings)
--   Equipment  (Id, Name, IsAvailable)
--   Borrowings (Id, StudentId, EquipmentId, DateBorrowed, ExpectedReturnDate,
--               ActualReturnDate, Status)       Status is text: 'Active' / 'Returned'
-- Booleans are stored as 1 / 0. Dates are text 'yyyy-MM-dd'.

-------------------------------------------------------------------------------
-- 1. Basic retrieval: all equipment
-------------------------------------------------------------------------------
SELECT *
FROM Equipment;

-------------------------------------------------------------------------------
-- 2. Filtering: only currently available equipment
-------------------------------------------------------------------------------
SELECT Id, Name
FROM Equipment
WHERE IsAvailable = 1
ORDER BY Id;

-------------------------------------------------------------------------------
-- 3. Join: active borrowings with the student and equipment information
-------------------------------------------------------------------------------
SELECT s.Name                AS Student,
       e.Name                AS Equipment,
       b.DateBorrowed        AS Borrowed,
       b.ExpectedReturnDate  AS Due
FROM Borrowings AS b
INNER JOIN Students  AS s ON s.Id = b.StudentId
INNER JOIN Equipment AS e ON e.Id = b.EquipmentId
WHERE b.Status = 'Active'
ORDER BY b.Id;

-------------------------------------------------------------------------------
-- 4. Aggregates
-------------------------------------------------------------------------------
-- 4a. Number of active borrowings
SELECT COUNT(*) AS ActiveBorrowings
FROM Borrowings
WHERE Status = 'Active';

-- 4b. Number of borrowings per student, with their limit
--     (LEFT JOIN keeps students who have never borrowed anything)
SELECT s.Name,
       s.MaxActiveBorrowings AS BorrowLimit,
       COUNT(b.Id)           AS TotalBorrowings,
       SUM(CASE WHEN b.Status = 'Active' THEN 1 ELSE 0 END) AS ActiveNow
FROM Students AS s
LEFT JOIN Borrowings AS b ON b.StudentId = s.Id
GROUP BY s.Id, s.Name, s.MaxActiveBorrowings
ORDER BY TotalBorrowings DESC, s.Name;

-- 4c. Equipment that is available vs. borrowed
SELECT CASE WHEN IsAvailable = 1 THEN 'Available' ELSE 'Unavailable' END AS State,
       COUNT(*) AS Total
FROM Equipment
GROUP BY IsAvailable;

-------------------------------------------------------------------------------
-- 5. Update: mark an item unavailable (e.g. sent for repair), then undo it.
--    Demonstration only - the application itself updates data through EF Core.
-------------------------------------------------------------------------------
UPDATE Equipment
SET IsAvailable = 0
WHERE Name = 'Logic Analyzer';

SELECT Id, Name, IsAvailable FROM Equipment WHERE Name = 'Logic Analyzer';

UPDATE Equipment
SET IsAvailable = 1
WHERE Name = 'Logic Analyzer';
