using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Infrastructure.Persistence;
using EquipmentBorrowing.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace EquipmentBorrowing.Infrastructure;

public static class DependencyInjection
{
    /// <summary>
    /// Registers SQLite, EF Core and the EF repositories. The Desktop project calls
    /// this one method, so Views and ViewModels never see SQLite or EF Core.
    ///
    /// Why a DbContext FACTORY instead of AddDbContext + scoped repositories:
    /// a desktop app has no "web request" to scope a DbContext to, so a scoped
    /// DbContext would live for the whole run and be shared by every screen.
    /// That breaks here for two reasons:
    ///   1. The ViewModels start loading data at the same time (fire-and-forget
    ///      ReloadAsync calls). A DbContext is not thread-safe, so two overlapping
    ///      queries on one context throw "A second operation was started...".
    ///   2. A long-lived context keeps old entities in memory. After equipment is
    ///      returned, a later GetById could hand back the stale tracked copy
    ///      (IsAvailable still false) instead of the row now in the database.
    /// With the factory, every repository method creates a short-lived context,
    /// uses it and disposes it, so each call sees the current database state.
    /// </summary>
    public static IServiceCollection AddPersistence(this IServiceCollection services, string databasePath)
    {
        var connectionString = $"Data Source={databasePath}";

        services.AddDbContextFactory<EquipmentBorrowingDbContext>(options =>
        {
            options.UseSqlite(connectionString);
#if DEBUG
            // Lab 3, Part N: print the SQL that EF Core generates (run with `dotnet run`
            // to see it in the terminal). Not compiled into Release builds.
            options.LogTo(
                Console.WriteLine,
                new[] { DbLoggerCategory.Database.Command.Name },
                Microsoft.Extensions.Logging.LogLevel.Information);
#endif
        });

        // Replace the three InMemory registrations from Lab 2. The repositories only
        // hold the (singleton) factory, so they are safe to register as singletons.
        services.AddSingleton<IStudentRepository, EfStudentRepository>();
        services.AddSingleton<IEquipmentRepository, EfEquipmentRepository>();
        services.AddSingleton<IBorrowingRepository, EfBorrowingRepository>();
        services.AddSingleton<IBorrowingQueries, EfBorrowingQueries>();

        return services;
    }

    /// <summary>
    /// Applies any pending migrations: creates the database file and tables (with the
    /// seed data) the first time, and does nothing on later runs. It never deletes or
    /// recreates an existing database, so stored data survives restarts.
    /// </summary>
    public static void InitializeDatabase(this IServiceProvider provider)
    {
        var factory = provider.GetRequiredService<IDbContextFactory<EquipmentBorrowingDbContext>>();

        using var db = factory.CreateDbContext();
        db.Database.Migrate();
    }
}
