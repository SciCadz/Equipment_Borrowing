using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Domain;
using EquipmentBorrowing.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace EquipmentBorrowing.Infrastructure.Repositories;

/// <summary>
/// SQLite-backed <see cref="IEquipmentRepository"/>.
///
/// Tracking decisions (Lab 3, Part O):
///  - Reads (GetById / GetAll / GetAvailable) use AsNoTracking(): the objects are
///    only displayed or inspected, and each read uses its own short-lived context,
///    so EF Core has nothing to gain from watching them.
///  - UpdateAsync is the operation that MODIFIES data. It attaches the changed
///    Equipment to a fresh context, so EF Core tracks it, and then flags the one
///    property that changed. SaveChangesAsync turns that into a single UPDATE.
/// </summary>
public class EfEquipmentRepository : IEquipmentRepository
{
    private readonly IDbContextFactory<EquipmentBorrowingDbContext> _contextFactory;

    public EfEquipmentRepository(IDbContextFactory<EquipmentBorrowingDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<Equipment?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        return await db.Equipment
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == id, cancellationToken);
    }

    public async Task<IReadOnlyList<Equipment>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        return await db.Equipment
            .AsNoTracking()
            .OrderBy(e => e.Id)
            .ToListAsync(cancellationToken);
    }

    // LINQ query 1 (Lab 3, Part M): equipment that can be borrowed right now.
    public async Task<IReadOnlyList<Equipment>> GetAvailableAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        return await db.Equipment
            .AsNoTracking()
            .Where(e => e.IsAvailable)
            .OrderBy(e => e.Id)
            .ToListAsync(cancellationToken);
    }

    public async Task UpdateAsync(Equipment equipment, CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        db.Equipment.Attach(equipment);                              // start tracking (state: Unchanged)
        db.Entry(equipment).Property(e => e.IsAvailable).IsModified = true;   // only this column changed

        await db.SaveChangesAsync(cancellationToken);
    }
}
