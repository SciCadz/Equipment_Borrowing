using EquipmentBorrowing.Application.Common;
using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Domain;
using EquipmentBorrowing.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace EquipmentBorrowing.Infrastructure.Repositories;

/// <summary>
/// SQLite-backed <see cref="IBorrowingQueries"/>: display-shaped queries that
/// join several tables. Nothing returned here is ever saved back, so there is
/// no tracking.
/// </summary>
public class EfBorrowingQueries : IBorrowingQueries
{
    private readonly IDbContextFactory<EquipmentBorrowingDbContext> _contextFactory;

    public EfBorrowingQueries(IDbContextFactory<EquipmentBorrowingDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    // LINQ query 2 (Lab 3, Part M): current borrowings WITH the student and equipment.
    // Replaces the Lab 2 approach of loading every active borrowing and then
    // looking up its student and its equipment one record at a time.
    public async Task<IReadOnlyList<ActiveBorrowingDetails>> GetActiveDetailsAsync(
        CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        return await (
            from b in db.Borrowings.AsNoTracking()
            join s in db.Students on b.StudentId equals s.Id
            join e in db.Equipment on b.EquipmentId equals e.Id
            where b.Status == BorrowingStatus.Active
            orderby b.Id
            select new ActiveBorrowingDetails(
                b.Id,
                s.Name,
                e.Name,
                b.DateBorrowed,
                b.ExpectedReturnDate))
            .ToListAsync(cancellationToken);
    }
}
