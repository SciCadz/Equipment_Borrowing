using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Domain;
using EquipmentBorrowing.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace EquipmentBorrowing.Infrastructure.Repositories;

/// <summary>
/// SQLite-backed <see cref="IBorrowingRepository"/>. Same pattern as
/// <see cref="EfEquipmentRepository"/>: reads are AsNoTracking, writes
/// (AddAsync / UpdateAsync) use a context that tracks the entity being saved.
/// </summary>
public class EfBorrowingRepository : IBorrowingRepository
{
    private readonly IDbContextFactory<EquipmentBorrowingDbContext> _contextFactory;

    public EfBorrowingRepository(IDbContextFactory<EquipmentBorrowingDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    // LINQ query 3 (Lab 3, Part M): how many active borrowings does a student have?
    // Used by BorrowEquipmentService to enforce Student.MaxActiveBorrowings.
    public async Task<int> CountActiveByStudentIdAsync(int studentId, CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        return await db.Borrowings
            .CountAsync(b => b.StudentId == studentId && b.Status == BorrowingStatus.Active, cancellationToken);
    }

    public async Task<Borrowing?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        return await db.Borrowings
            .AsNoTracking()
            .FirstOrDefaultAsync(b => b.Id == id, cancellationToken);
    }

    public async Task<IReadOnlyList<Borrowing>> GetActiveAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        return await db.Borrowings
            .AsNoTracking()
            .Where(b => b.Status == BorrowingStatus.Active)
            .OrderBy(b => b.Id)
            .ToListAsync(cancellationToken);
    }

    public async Task<Borrowing> AddAsync(Borrowing borrowing, CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        // The service passes a placeholder id of 0; SQLite assigns the real one
        // on insert and EF Core copies it back onto this same object.
        db.Borrowings.Add(borrowing);
        await db.SaveChangesAsync(cancellationToken);

        return borrowing;
    }

    public async Task UpdateAsync(Borrowing borrowing, CancellationToken cancellationToken = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(cancellationToken);

        // Used after Borrowing.MarkAsReturned(): only Status and ActualReturnDate change.
        db.Borrowings.Attach(borrowing);
        db.Entry(borrowing).Property(b => b.Status).IsModified = true;
        db.Entry(borrowing).Property(b => b.ActualReturnDate).IsModified = true;

        await db.SaveChangesAsync(cancellationToken);
    }
}
