using EquipmentBorrowing.Domain;
using Microsoft.EntityFrameworkCore;

namespace EquipmentBorrowing.Infrastructure.Persistence;

/// <summary>
/// EF Core's gateway to the SQLite database. It knows the three tables
/// (Students, Equipment, Borrowings), loads the entity configurations that
/// describe how the Domain classes map to those tables, and writes changes
/// with SaveChangesAsync.
///
/// Only the EF repositories in this project create and use it. Views,
/// ViewModels and Application services never see it.
/// </summary>
public class EquipmentBorrowingDbContext : DbContext
{
    public EquipmentBorrowingDbContext(DbContextOptions<EquipmentBorrowingDbContext> options)
        : base(options)
    {
    }

    public DbSet<Student> Students => Set<Student>();
    public DbSet<Equipment> Equipment => Set<Equipment>();
    public DbSet<Borrowing> Borrowings => Set<Borrowing>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Finds StudentConfiguration, EquipmentConfiguration and BorrowingConfiguration.
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(EquipmentBorrowingDbContext).Assembly);
    }
}
