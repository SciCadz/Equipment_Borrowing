using EquipmentBorrowing.Domain;

namespace EquipmentBorrowing.Infrastructure.Persistence;

/// <summary>
/// The initial rows inserted by the InitialCreate migration (via HasData in the
/// entity configurations). The students and equipment are the same ones the
/// Lab 2 app used to create in memory at startup, plus two borrowing records
/// so the database demonstrates every state:
///
///   - available equipment            (100, 102, 103, 104)
///   - borrowed / unavailable equipment (101 Oscilloscope, held by Juan)
///   - a student who may NOT borrow   (3, Pedro Reyes)  -> failed-borrow demo
///   - a student near a limit         (2, Maria, max 2) -> limit demo
///   - one active and one returned borrowing
/// </summary>
internal static class SeedData
{
    public static Student[] GetStudents() => new[]
    {
        new Student(1, "Juan Dela Cruz", isAllowedToBorrow: true,  maxActiveBorrowings: 3),
        new Student(2, "Maria Santos",   isAllowedToBorrow: true,  maxActiveBorrowings: 2),
        new Student(3, "Pedro Reyes",    isAllowedToBorrow: false, maxActiveBorrowings: 3)
    };

    public static Equipment[] GetEquipment() => new[]
    {
        new Equipment(100, "Digital Multimeter"),
        new Equipment(101, "Oscilloscope", isAvailable: false),   // borrowed by Juan (borrowing #1)
        new Equipment(102, "Function Generator"),
        new Equipment(103, "Soldering Iron"),
        new Equipment(104, "Logic Analyzer")
    };

    public static Borrowing[] GetBorrowings()
    {
        // #1: still active - Juan has the Oscilloscope.
        var active = new Borrowing(
            id: 1, studentId: 1, equipmentId: 101,
            dateBorrowed: new DateOnly(2026, 9, 28),
            expectedReturnDate: new DateOnly(2026, 10, 5));

        // #2: history - Maria borrowed and already returned the Multimeter.
        var returned = new Borrowing(
            id: 2, studentId: 2, equipmentId: 100,
            dateBorrowed: new DateOnly(2026, 9, 14),
            expectedReturnDate: new DateOnly(2026, 9, 21));
        returned.MarkAsReturned(new DateOnly(2026, 9, 19));

        return new[] { active, returned };
    }
}
