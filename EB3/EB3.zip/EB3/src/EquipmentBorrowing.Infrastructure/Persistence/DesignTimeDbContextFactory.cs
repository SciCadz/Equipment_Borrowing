using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace EquipmentBorrowing.Infrastructure.Persistence;

/// <summary>
/// Used only by the `dotnet ef` command-line tool (migrations add / database update)
/// so it can build a DbContext without starting the Avalonia app. The running
/// application gets its DbContext from the registration in DependencyInjection.cs.
/// </summary>
public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<EquipmentBorrowingDbContext>
{
    public EquipmentBorrowingDbContext CreateDbContext(string[] args)
    {
        var options = new DbContextOptionsBuilder<EquipmentBorrowingDbContext>()
            .UseSqlite("Data Source=equipmentborrowing.design.db")
            .Options;

        return new EquipmentBorrowingDbContext(options);
    }
}
