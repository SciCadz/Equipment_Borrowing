using EquipmentBorrowing.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EquipmentBorrowing.Infrastructure.Persistence.Configurations;

public class BorrowingConfiguration : IEntityTypeConfiguration<Borrowing>
{
    public void Configure(EntityTypeBuilder<Borrowing> builder)
    {
        builder.ToTable("Borrowings", t =>
            t.HasCheckConstraint(
                "CK_Borrowings_ExpectedAfterBorrowed",
                "\"ExpectedReturnDate\" >= \"DateBorrowed\""));

        builder.HasKey(b => b.Id);
        builder.Property(b => b.Id).ValueGeneratedOnAdd();   // SQLite assigns the id; the service passes 0

        builder.Property(b => b.StudentId).IsRequired();
        builder.Property(b => b.EquipmentId).IsRequired();

        // DateOnly is stored by the SQLite provider as text "yyyy-MM-dd".
        builder.Property(b => b.DateBorrowed).IsRequired();
        builder.Property(b => b.ExpectedReturnDate).IsRequired();
        builder.Property(b => b.ActualReturnDate);           // optional: NULL until returned

        // Stored as readable text ("Active" / "Returned") instead of 0 / 1.
        builder.Property(b => b.Status)
            .IsRequired()
            .HasConversion<string>()
            .HasMaxLength(20);

        // Borrowing is the "many" side of both relationships. The Domain class
        // only holds ids (no Student / Equipment object references), so the
        // relationships are declared without navigation properties.
        builder.HasOne<Student>()
            .WithMany()
            .HasForeignKey(b => b.StudentId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);               // history must never be silently deleted

        builder.HasOne<Equipment>()
            .WithMany()
            .HasForeignKey(b => b.EquipmentId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);

        // "How many active borrowings does this student have?" and history per student.
        builder.HasIndex(b => b.StudentId);

        // The database itself refuses a second ACTIVE borrowing of the same equipment
        // (partial unique index) - a safety net behind the service's availability check.
        builder.HasIndex(b => b.EquipmentId)
            .IsUnique()
            .HasFilter("\"Status\" = 'Active'")
            .HasDatabaseName("UX_Borrowings_ActiveEquipment");

        builder.HasData(SeedData.GetBorrowings());
    }
}
