using EquipmentBorrowing.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EquipmentBorrowing.Infrastructure.Persistence.Configurations;

public class StudentConfiguration : IEntityTypeConfiguration<Student>
{
    public void Configure(EntityTypeBuilder<Student> builder)
    {
        builder.ToTable("Students", t =>
            t.HasCheckConstraint("CK_Students_MaxActiveBorrowings", "\"MaxActiveBorrowings\" > 0"));

        // The Domain classes have get-only properties set through their
        // constructors. EF Core does not map such properties by convention,
        // so every property is configured explicitly here. EF fills them
        // through the constructor / backing field when it loads a row.
        builder.HasKey(s => s.Id);
        builder.Property(s => s.Id).ValueGeneratedNever();   // ids are assigned by the seed data

        builder.Property(s => s.Name)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(s => s.IsAllowedToBorrow)
            .IsRequired();

        builder.Property(s => s.MaxActiveBorrowings)
            .IsRequired();

        builder.HasData(SeedData.GetStudents());
    }
}
