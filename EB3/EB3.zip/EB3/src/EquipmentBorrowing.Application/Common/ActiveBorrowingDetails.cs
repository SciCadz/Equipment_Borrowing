namespace EquipmentBorrowing.Application.Common;

/// <summary>
/// Read model for the "Active Borrowings" screen: one active borrowing together
/// with the student's and equipment's names. It exists so the data store can
/// answer "who has what?" in a single join query instead of the screen
/// looking up every student and equipment record one at a time.
/// </summary>
public record ActiveBorrowingDetails(
    int BorrowingId,
    string StudentName,
    string EquipmentName,
    DateOnly DateBorrowed,
    DateOnly ExpectedReturnDate);
