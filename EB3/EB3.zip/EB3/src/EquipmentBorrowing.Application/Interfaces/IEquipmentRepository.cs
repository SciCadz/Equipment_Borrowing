using EquipmentBorrowing.Domain;

namespace EquipmentBorrowing.Application.Interfaces;

/// <summary>
/// Abstraction over wherever Equipment data actually lives. Exposes what the
/// Borrow Equipment use case needs (looking equipment up by id, persisting
/// an availability change), plus listing equipment for display purposes.
/// </summary>
public interface IEquipmentRepository
{
    Task<Equipment?> GetByIdAsync(int id, CancellationToken cancellationToken = default);

    /// <summary>
    /// All equipment, for display purposes (e.g. the "Equipment" screen).
    /// </summary>
    Task<IReadOnlyList<Equipment>> GetAllAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Only the equipment that can be borrowed right now (Lab 3), for the
    /// "Show only available" filter on the Equipment screen.
    /// </summary>
    Task<IReadOnlyList<Equipment>> GetAvailableAsync(CancellationToken cancellationToken = default);

    Task UpdateAsync(Equipment equipment, CancellationToken cancellationToken = default);
}
