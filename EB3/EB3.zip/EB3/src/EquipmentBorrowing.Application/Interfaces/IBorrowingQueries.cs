using EquipmentBorrowing.Application.Common;

namespace EquipmentBorrowing.Application.Interfaces;

/// <summary>
/// Read-only queries that combine data from several tables (Borrowings,
/// Students, Equipment). Kept separate from <see cref="IBorrowingRepository"/>
/// because they return display-shaped data, not domain entities that will be
/// modified and saved.
/// </summary>
public interface IBorrowingQueries
{
    /// <summary>
    /// All currently active borrowings with the student's and equipment's
    /// names, for the "Active Borrowings" screen.
    /// </summary>
    Task<IReadOnlyList<ActiveBorrowingDetails>> GetActiveDetailsAsync(CancellationToken cancellationToken = default);
}
