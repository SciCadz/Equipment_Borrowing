using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Application.Services;
using EquipmentBorrowing.Desktop.ViewModels;
using EquipmentBorrowing.Infrastructure;
using Microsoft.Extensions.DependencyInjection;

namespace EquipmentBorrowing.Desktop;

public partial class App : Avalonia.Application
{
    public static IServiceProvider Services { get; private set; } = null!;

    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        var services = new ServiceCollection();
        ConfigureServices(services);
        Services = services.BuildServiceProvider();

        // Lab 3: create the SQLite database (tables + seed data) on first run, or apply
        // any newer migrations. Existing data is kept - nothing is deleted or recreated.
        Services.InitializeDatabase();

        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            // MainWindowViewModel (and, transitively, EquipmentViewModel and
            // BorrowingsViewModel) is resolved here rather than "new"-ed up -
            // this is the one place in the app that knows how the object
            // graph is wired together.
            desktop.MainWindow = new MainWindow
            {
                DataContext = Services.GetRequiredService<MainWindowViewModel>()
            };
        }

        base.OnFrameworkInitializationCompleted();
    }

    /// <summary>
    /// The single composition point for the application (Part H). Every
    /// repository, service, and ViewModel is registered here, once, and
    /// everything else receives its dependencies through its constructor -
    /// nothing below this method ever calls "new" on a repository or service.
    /// </summary>
    private static void ConfigureServices(IServiceCollection services)
    {
        // Lab 3: repositories now store data in a SQLite file instead of memory.
        // AddPersistence (Infrastructure) registers the EF Core repositories behind the
        // same IStudentRepository / IEquipmentRepository / IBorrowingRepository
        // interfaces, so nothing below this line had to change.
        services.AddPersistence(GetDatabasePath());

        services.AddTransient<BorrowEquipmentService>();
        services.AddTransient<ReturnEquipmentService>();

        services.AddTransient<EquipmentViewModel>();
        services.AddTransient<BorrowingsViewModel>();
        services.AddTransient<MainWindowViewModel>();
    }

    /// <summary>
    /// The database lives in the user's local application-data folder (not in bin/),
    /// so rebuilding the project never deletes the stored borrowings.
    /// </summary>
    private static string GetDatabasePath()
    {
        var folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "EquipmentBorrowing");

        Directory.CreateDirectory(folder);
        return Path.Combine(folder, "equipmentborrowing.db");
    }
}
