using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using EquipmentBorrowing.Application.Common;
using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Application.Services;

namespace EquipmentBorrowing.Desktop.ViewModels;

/// <summary>
/// Backs the Active Borrowings screen: lists everything currently active,
/// and hands a return request to <see cref="ReturnEquipmentService"/>
/// (Part F). Like <see cref="EquipmentViewModel"/>, it never re-implements
/// the business rule about whether a borrowing can be returned.
/// </summary>
public partial class BorrowingsViewModel : ObservableObject, IRecipient<BorrowingStateChangedMessage>
{
    private readonly IBorrowingQueries _borrowingQueries;
    private readonly ReturnEquipmentService _returnEquipmentService;

    public ObservableCollection<BorrowingListItem> ActiveBorrowings { get; } = new();

    [ObservableProperty]
    private BorrowingListItem? selectedBorrowing;

    [ObservableProperty]
    private string? statusMessage;

    public BorrowingsViewModel(
        IBorrowingQueries borrowingQueries,
        ReturnEquipmentService returnEquipmentService)
    {
        _borrowingQueries = borrowingQueries;
        _returnEquipmentService = returnEquipmentService;

        WeakReferenceMessenger.Default.RegisterAll(this);

        _ = ReloadAsync();
    }

    public async Task ReloadAsync()
    {
        // Lab 3: one query returns each active borrowing together with the student's
        // and equipment's names (a join in the database), instead of one lookup per row.
        var details = await _borrowingQueries.GetActiveDetailsAsync();

        var items = details
            .Select(d => new BorrowingListItem(
                d.BorrowingId,
                d.StudentName,
                d.EquipmentName,
                d.DateBorrowed,
                d.ExpectedReturnDate))
            .ToList();

        ActiveBorrowings.Clear();
        foreach (var item in items)
            ActiveBorrowings.Add(item);
    }

    [RelayCommand]
    private async Task ReturnAsync()
    {
        if (SelectedBorrowing is null)
        {
            StatusMessage = "Please select a borrowing to return.";
            return;
        }

        var request = new ReturnEquipmentRequest(SelectedBorrowing.Id, DateOnly.FromDateTime(DateTime.Today));
        var result = await _returnEquipmentService.ExecuteAsync(request);

        StatusMessage = result.IsSuccess
            ? $"Borrowing #{result.Borrowing!.Id} returned."
            : DescribeFailure(result.FailureReason);

        if (result.IsSuccess)
        {
            await ReloadAsync();
            WeakReferenceMessenger.Default.Send(new BorrowingStateChangedMessage());
        }
    }

    private static string DescribeFailure(ReturnFailureReason reason) => reason switch
    {
        ReturnFailureReason.BorrowingNotFound => "That borrowing could not be found.",
        ReturnFailureReason.BorrowingAlreadyReturned => "That borrowing has already been returned.",
        _ => "The return request could not be completed."
    };

    /// <summary>
    /// Called when the Equipment screen completes a borrow, so a newly
    /// created active borrowing shows up here without polling.
    /// </summary>
    public void Receive(BorrowingStateChangedMessage message) => _ = ReloadAsync();
}
