using EquipmentBorrowing.Application.Common;
using EquipmentBorrowing.Application.Interfaces;
using EquipmentBorrowing.Application.Services;
using EquipmentBorrowing.Domain;
using EquipmentBorrowing.Infrastructure;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace EquipmentBorrowing.Tests;

/// <summary>
/// Lab 3 persistence tests. Each "application run" is a brand-new service provider
/// pointed at the same SQLite file, which is what restarting the app does.
/// NOTE: these need the InitialCreate migration to exist in the Infrastructure
/// project (dotnet ef migrations add InitialCreate) before they can pass.
/// </summary>
public class EfPersistenceTests : IDisposable
{
    private readonly string _databasePath =
        Path.Combine(Path.GetTempPath(), $"equipment-borrowing-test-{Guid.NewGuid():N}.db");

    private static readonly DateOnly Today = new(2026, 10, 4);
    private static readonly DateOnly Due = new(2026, 10, 11);

    /// <summary>Starts one "run" of the application against the test database file.</summary>
    private ServiceProvider StartApplication()
    {
        var services = new ServiceCollection();
        services.AddPersistence(_databasePath);
        services.AddTransient<BorrowEquipmentService>();
        services.AddTransient<ReturnEquipmentService>();

        var provider = services.BuildServiceProvider();
        provider.InitializeDatabase();   // applies migrations; keeps existing data
        return provider;
    }

    [Fact]
    public async Task SeedData_IsCreatedOnFirstRun()
    {
        using var app = StartApplication();

        var equipment = await app.GetRequiredService<IEquipmentRepository>().GetAllAsync();
        var students = await app.GetRequiredService<IStudentRepository>().GetAllAsync();
        var active = await app.GetRequiredService<IBorrowingQueries>().GetActiveDetailsAsync();

        Assert.Equal(5, equipment.Count);
        Assert.Equal(3, students.Count);
        Assert.Single(active);
        Assert.Equal("Oscilloscope", active[0].EquipmentName);
        Assert.Equal("Juan Dela Cruz", active[0].StudentName);
    }

    [Fact]
    public async Task Borrowing_And_Return_SurviveApplicationRestart()
    {
        int borrowingId;

        // Run 1: borrow the Function Generator (102) as Maria (2).
        using (var run1 = StartApplication())
        {
            var result = await run1.GetRequiredService<BorrowEquipmentService>()
                .ExecuteAsync(new BorrowEquipmentRequest(2, 102, Today, Due));

            Assert.True(result.IsSuccess);
            borrowingId = result.Borrowing!.Id;
            Assert.True(borrowingId > 0);   // SQLite assigned a real id
        }

        // Run 2 ("restart"): the borrowing is still there and the equipment is unavailable.
        using (var run2 = StartApplication())
        {
            var active = await run2.GetRequiredService<IBorrowingQueries>().GetActiveDetailsAsync();
            Assert.Contains(active, d => d.BorrowingId == borrowingId && d.EquipmentName == "Function Generator");

            var equipment = await run2.GetRequiredService<IEquipmentRepository>().GetByIdAsync(102);
            Assert.False(equipment!.IsAvailable);

            // Return it.
            var returned = await run2.GetRequiredService<ReturnEquipmentService>()
                .ExecuteAsync(new ReturnEquipmentRequest(borrowingId, Due));
            Assert.True(returned.IsSuccess);
        }

        // Run 3 ("restart" again): the return was preserved.
        using (var run3 = StartApplication())
        {
            var active = await run3.GetRequiredService<IBorrowingQueries>().GetActiveDetailsAsync();
            Assert.DoesNotContain(active, d => d.BorrowingId == borrowingId);

            var borrowing = await run3.GetRequiredService<IBorrowingRepository>().GetByIdAsync(borrowingId);
            Assert.Equal(BorrowingStatus.Returned, borrowing!.Status);
            Assert.Equal(Due, borrowing.ActualReturnDate);

            var equipment = await run3.GetRequiredService<IEquipmentRepository>().GetByIdAsync(102);
            Assert.True(equipment!.IsAvailable);
        }
    }

    [Fact]
    public async Task GetAvailableAsync_ExcludesBorrowedEquipment()
    {
        using var app = StartApplication();

        var available = await app.GetRequiredService<IEquipmentRepository>().GetAvailableAsync();

        Assert.DoesNotContain(available, e => e.Id == 101);   // Oscilloscope is borrowed in the seed data
        Assert.Equal(4, available.Count);
    }

    [Fact]
    public async Task StudentNotAllowedToBorrow_IsStillRejected_WithSqlite()
    {
        using var app = StartApplication();

        var result = await app.GetRequiredService<BorrowEquipmentService>()
            .ExecuteAsync(new BorrowEquipmentRequest(3, 102, Today, Due));   // Pedro Reyes (3)

        Assert.False(result.IsSuccess);
        Assert.Equal(BorrowFailureReason.StudentNotAllowedToBorrow, result.FailureReason);
    }

    public void Dispose()
    {
        // Microsoft.Data.Sqlite pools connections; release them so the file can be deleted.
        SqliteConnection.ClearAllPools();

        foreach (var path in new[] { _databasePath, _databasePath + "-shm", _databasePath + "-wal" })
        {
            try { if (File.Exists(path)) File.Delete(path); } catch (IOException) { /* best effort */ }
        }
    }
}
